/* console.log("test");*/

let var_test = "sdfERTwERTdfgERTeERTdfgERTlRTYdfgERTlRTYdfgERT ERTdfgERTdZERdfgERToERTdfgERTnERTdfgERTeERTsdf"


let new_var = var_test.replace(/sdf|ERT|dfg|RTY|ZER/g, "");


console.log(new_var);
/*console.log(var_test.replace('ERT', ''));*/

